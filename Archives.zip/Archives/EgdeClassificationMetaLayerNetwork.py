import torch
from torch_geometric.nn import MetaLayer
from torch_scatter import scatter_mean
from torch_geometric.nn.models import GAT
from torch_geometric.nn import GATConv
from torch.nn import Linear, ReLU
from torch_geometric.nn import Sequential, GCNConv
class Edge_Model(torch.nn.Module):

    def __init__(self, num_node_feat, num_edge_feat, num_global_feat, hiddens):
        super(Edge_Model, self).__init__()
        in_channels = ( 2 * num_node_feat + num_edge_feat)


        self.edge_mlp = torch.nn.Sequential(
            torch.nn.Linear(2 * num_node_feat + num_edge_feat, hiddens),
            torch.nn.ReLU(),
            torch.nn.Linear(hiddens, 64)
        )
    
    def forward(self, src, dest, edge_attr, u=None, batch=None):
        out = torch.cat([src, dest, edge_attr], 1)
        out = self.edge_mlp(out)
        return out

class Node_Model(torch.nn.Module):

    def __init__(self, num_node_feat, num_edge_feat, num_global_feat, hiddens):

        super(Node_Model, self).__init__()
        
        self.node_mlp_1 = torch.nn.Sequential(
            torch.nn.Linear(num_node_feat + 64, hiddens),
            torch.nn.ReLU(),
            torch.nn.Linear(hiddens, 256)
        )
        self.node_mlp_2 = torch.nn.Sequential(
            torch.nn.Linear(hiddens + num_node_feat, hiddens),
            torch.nn.ReLU(),
            torch.nn.Linear(hiddens, 256)
        )
        self.core =  GAT(72, hiddens,5)

    def forward(self, x, edge_index, edge_attr, u, batch):
        row, col = edge_index
        #out = torch.cat([x[col], edge_attr], dim=1)
        out = torch.cat([x[row], edge_attr], dim=1)
        #out = self.node_mlp_1(out)
        #out = scatter_mean(out, row, dim=0, dim_size=x.size(0))
        #out = torch.cat([x, out], dim=1)
        #out = self.node_mlp_2(out)
        return self.core(out, edge_index)


def build_meta_layer(num_edge_feat, num_node_feat, num_global_feat, hiddens):
     return MetaLayer(Edge_Model(num_edge_feat, num_node_feat, num_global_feat, hiddens),
                 Node_Model(num_edge_feat, num_node_feat, num_global_feat, hiddens)
                 )

class _ParityGameGAT(torch.nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, edge_index, edge_attr, u, batch=None): 

        x, updated_edge_attr, u = self.metaLayer(x, edge_index, edge_attr, u, batch)
 
        #x = self.core(x, edge_index)
        #x_src, x_dst = x[edge_index[0]], x[edge_index[1]]

        #edge_feat = torch.cat([x_src, x_dst, updated_edge_attr], dim=-1)

       
        return (self.node_classifier(x), self.edge_classifier(updated_edge_attr))
        



class ParityGameGAT(_ParityGameGAT):
    


    def __init__(self, hidden_channels_nodes, hidden_channels_edges, core_iterations):
        super().__init__()

        self.metaLayer = build_meta_layer(8, 8, 6, 256)
        self.core = GAT(128, hidden_channels_nodes, core_iterations, jk='lstm', flow='target_to_source')
        self.node_classifier = torch.nn.Sequential(
            torch.nn.Linear(hidden_channels_nodes, hidden_channels_nodes),  
            torch.nn.ReLU(),
            torch.nn.Dropout(p=0.2),
            torch.nn.Linear(hidden_channels_edges, 2),
            torch.nn.Softmax(dim=1)
        )

        self.edge_classifier = torch.nn.Sequential(
            torch.nn.Linear( 64, hidden_channels_edges),
            torch.nn.ReLU(),
            torch.nn.Dropout(p=0.2),
            torch.nn.Linear(hidden_channels_edges, 2),
            torch.nn.Softmax(dim=1)
        )





