import numpy as np
import pandas as pd
import os
from gnn_pg_solver import Training
from torch_geometric.loader import DataLoader
from pre_process_game_data import ModifyGameData
import torch.nn.functional as F 
from EgdeClassificationMetaLayerNetwork import ParityGameGAT
from modified_game_dataset import ModifiedGameDataset
import torch

class TrainPhase(Training):
    
    
    def train(self, mod_games, solutions):
        data = ModifiedGameDataset('pg_data_20230308', mod_games, solutions)
        train_loader = DataLoader(data, batch_size=5, shuffle=True)

        self._train_internal(train_loader)

        torch.save(self._network.state_dict(), self._output_stream)

    def _train_internal(self, loader):


        optimizer = torch.optim.Adam(self._network.parameters(), lr=0.001)
        criterion_nodes = torch.nn.CrossEntropyLoss()
        criterion_edges = torch.nn.CrossEntropyLoss(weight= torch.tensor([0.2, 1.0]).cuda()) #weight= torch.tensor([1.0, 1.0]).cuda()
        
        for epoch in range(1, 1000):

            self._network.train()

            running_loss = 0.
            i = 0

            for data in loader:  # Iterate in batches over the training dataset.
                i += 1
                optimizer.zero_grad() 
                
                src, des = data.edge_index.cuda() 

                out_nodes, out_edges = self._network(data.x.cuda(), data.edge_index.cuda(), data.edge_attr.cuda(), data.u.cuda(), data.batch.cuda())
                

                loss = criterion_nodes(out_nodes, data.y_nodes) + criterion_edges(out_edges, data.y_edges)  
                #loss = F.cross_entropy(scores, data.y_edges.cuda())
                
                
                loss.backward()  # Derive gradients.
                optimizer.step()  # Update parameters based on gradients.

                running_loss += loss.item()
                if i % 50 == 0:
                    last_loss = running_loss / 50  # loss per batch
                    running_loss = 0.
            print('epoch: ', epoch, 'loss: ', running_loss)

def train(mod_game_root_dir = None, sol_root_dir = None, output_wt_file=None):

    if mod_game_root_dir == None: 

        mod_game_root_dir= os.path.join(os.getcwd(),'games-small/mod_games_train')
    if sol_root_dir== None:  

        sol_root_dir = os.path.join(os.getcwd(),'games-small/sol_train')
    if output_wt_file == None: 
        output_wt_file = os.path.join(os.getcwd(),'GATConv_weights.pth')

    training = TrainPhase()


    training.network = ParityGameGAT(256, 256, 10).cuda()

    training.output = output_wt_file
    
    mod_game_files = os.listdir(os.path.normpath(mod_game_root_dir))
    mod_game_files.sort()

    sol_files = os.listdir(os.path.normpath(sol_root_dir))
    sol_files.sort()

    mod_games = [pd.read_csv(os.path.join(os.path.normpath(mod_game_root_dir) , file))  for file in  mod_game_files]
    solutions = []
    
    for sol_file in sol_files: 
        with open(os.path.join(os.path.normpath(sol_root_dir) , sol_file)) as f: 
            solutions.append(f.readlines())
    training.train(mod_games, solutions)

class PredictPhase():

    def predict(self, mod_game_files):
        self._network.load_state_dict(torch.load(self._weights), strict=True)
        strategies = []
        file_names = []
        predictions = {}
        for mod_game_file in mod_game_files:
                f, s = self._predict_single(input= pd.read_csv(mod_game_file), identifier= mod_game_file)
                file_names.append(f)
                strategies.append(s)
        predictions['file'] = file_names
        predictions['strategies'] = strategies
        pd.DataFrame(predictions).to_csv('results_edge_classification.csv', header=None)

    def _predict_single(self, input, identifier=None):

        
        nodes, edges, node_attr = ModifyGameData.parse_mod_game_file(input)
        edge_attr, global_attributes = ModifyGameData.parse_mod_game_edge_attr(input)
        out_nodes, out_edges = self._network(torch.tensor(node_attr, dtype=torch.float),
                                     torch.tensor(edges, dtype=torch.long).t().contiguous(), torch.tensor(edge_attr, dtype=torch.float), torch.tensor(global_attributes, dtype=torch.float))
        
        winning_region = [str(node) for node in range(len(out_nodes)) if out_nodes[node][0].item() > out_nodes[node][1].item()]
 
    

        winning_edges = [(edges[i][0],edges[i][1]) for i in range (0, len(out_edges)) if out_edges[i][1].item()> out_edges[i][0].item()]
        if identifier is not None: 
            file_name = os.path.basename(identifier)
        else: 
            file_name = "Unidentified"
    

        print("Predicting for....." + str(file_name))

        return (file_name, winning_edges)

    @property
    def network(self):
        return self._network

    @network.setter
    def network(self, value):
        self._network = value

    @property
    def weights(self):
        return self._weights

    @weights.setter
    def weights(self, value):
        self._weights = value

    @property
    def output(self):
        return self._output

    @output.setter
    def output(self, value):
        self._output = value

def predict(weights =None, mod_game_file_root = None):
    if weights == None: 
        weights = os.path.join(os.getcwd(),'GATConv_weights.pth')
    if mod_game_file_root == None: 
        mod_game_file_root = os.path.join(os.getcwd(),'games-small/mod_games_test')

    mod_game_file_names = os.listdir(os.path.normpath(mod_game_file_root))
    mod_game_file_names.sort()
    mod_game_files = [os.path.join(os.path.normpath(mod_game_file_root), file) for file in mod_game_file_names]
    

    predictor = PredictPhase()

    
    predictor.network = ParityGameGAT(256, 256, 10)
    
    predictor.weights = weights

    predictor.predict(mod_game_files)

    
def main(): 
    cuda_id = torch.cuda.current_device()
    device = torch.device(cuda_id)  

    train()
    #predict()


if __name__ == '__main__': 
    main()
    


    

